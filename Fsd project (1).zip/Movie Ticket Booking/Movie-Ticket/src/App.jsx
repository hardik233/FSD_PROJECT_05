import React from 'react'
import Navbar from './Components/Navbar'
import { Route, Routes } from 'react-router-dom'
import Home from './Pages/Home'
import Movies from './Pages/Movies'
import MovieDetails from './Pages/MovieDetails'
import SeatLayout from './Pages/SeatLayout'
import MyBookings from  './Pages/MyBookings'
import Fav from './Pages/Fav'

const App = () => {
  return (
    <>
      <Navbar /> 
      <Routes >
        <Route path = '/' element={<Home/>} />
        <Route path = '/Movies' element={<Movies/>} />
        <Route path = '/Movies/:id' element={<MovieDetails/>} />
        <Route path = '/Movies/:id/:date' element={<SeatLayout/>} />
        <Route path = '/MyBookings' element={<MyBookings/>} />
        <Route path = '/Fav' element={<Fav/>} />
      </Routes>
    </>
  )
}

export default App
